'use client';

import { useSyncExternalStore } from 'react';
import { DEFAULT_LANGUAGE } from '@/lib/languages';
import { DEFAULT_PROVIDER } from '@/lib/providers';

const KEY_STORAGE = 'cinedeck.tmdb.key';
const SETTINGS_STORAGE = 'cinedeck.settings';

export interface CinedeckSettings {
  /** TMDB language code, e.g. "en-US" */
  language: string;
  /** Persist watch progress to /api/history */
  saveHistory: boolean;
  /** Preferred provider id (null → default server) */
  preferredServer: string | null;
  /** Hex accent color (e.g. "#fbbf24"). Applied to :root as --cinedeck-accent. */
  accentColor: string;
}

export const DEFAULT_SETTINGS: CinedeckSettings = {
  language: DEFAULT_LANGUAGE,
  saveHistory: true,
  preferredServer: null,
  accentColor: '#fbbf24',
};

/**
 * Apply the saved accent color to document.documentElement so all
 * `bg-brand` / `text-brand` / `border-brand` classes repaint live.
 * Idempotent — safe to call on every settings change.
 */
export function applyAccentColor(color: string | null | undefined): void {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  const value = color && /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(color) ? color : '#fbbf24';
  root.style.setProperty('--cinedeck-accent', value);
  // Auto-pick foreground based on luminance: dark text on bright accents,
  // white text on dark accents. Keeps button text readable for any color.
  const hex = value.replace('#', '');
  const full = hex.length === 3 ? hex.split('').map((c) => c + c).join('') : hex;
  const r = parseInt(full.slice(0, 2), 16) / 255;
  const g = parseInt(full.slice(2, 4), 16) / 255;
  const b = parseInt(full.slice(4, 6), 16) / 255;
  const luminance = 0.2126 * r + 0.7152 * g + 0.0722 * b;
  root.style.setProperty('--cinedeck-accent-foreground', luminance > 0.55 ? '#09090b' : '#ffffff');
}

// ---------------------------------------------------------------------------
// Tiny pub/sub so React components can react to localStorage changes.
// Snapshots are cached so useSyncExternalStore sees stable references.
// ---------------------------------------------------------------------------

type Listener = () => void;
const listeners = new Set<Listener>();
let cachedKey: string | null = null;
let cachedKeySnapshot = false;
let cachedSettings: CinedeckSettings | null = null;

function emit(): void {
  cachedKey = null;
  cachedSettings = null;
  listeners.forEach((l) => l());
}

if (typeof window !== 'undefined') {
  window.addEventListener('storage', (event) => {
    if (event.key === KEY_STORAGE || event.key === SETTINGS_STORAGE) emit();
  });
}

function subscribe(listener: Listener): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/** Public alias of `subscribe` for non-hook consumers (e.g. AppProviders useEffect). */
export const subscribeToSettings = subscribe;

// ---------------------------------------------------------------------------
// TMDB key
// ---------------------------------------------------------------------------

export function getTmdbKey(): string {
  if (typeof window === 'undefined') return '';
  if (cachedKey === null) {
    try {
      cachedKey = (window.localStorage.getItem(KEY_STORAGE) ?? '').trim();
    } catch {
      cachedKey = '';
    }
  }
  return cachedKey;
}

export function setTmdbKey(key: string): void {
  try {
    window.localStorage.setItem(KEY_STORAGE, key.trim());
  } catch {
    // storage full / private mode — ignore
  }
  emit();
}

export function clearTmdbKey(): void {
  try {
    window.localStorage.removeItem(KEY_STORAGE);
  } catch {
    // ignore
  }
  emit();
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

export function getSettings(): CinedeckSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  if (cachedSettings === null) {
    try {
      const raw = window.localStorage.getItem(SETTINGS_STORAGE);
      if (!raw) {
        cachedSettings = DEFAULT_SETTINGS;
      } else {
        const parsed = JSON.parse(raw) as Partial<CinedeckSettings>;
        cachedSettings = {
          language:
            typeof parsed.language === 'string' && parsed.language
              ? parsed.language
              : DEFAULT_LANGUAGE,
          saveHistory: typeof parsed.saveHistory === 'boolean' ? parsed.saveHistory : true,
          preferredServer:
            typeof parsed.preferredServer === 'string' && parsed.preferredServer
              ? parsed.preferredServer
              : parsed.preferredServer === null
                ? null
                : DEFAULT_PROVIDER,
          accentColor:
            typeof parsed.accentColor === 'string' &&
            /^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(parsed.accentColor)
              ? parsed.accentColor
              : '#fbbf24',
        };
      }
    } catch {
      cachedSettings = DEFAULT_SETTINGS;
    }
  }
  return cachedSettings;
}

export function updateSettings(patch: Partial<CinedeckSettings>): CinedeckSettings {
  const next = { ...getSettings(), ...patch };
  try {
    window.localStorage.setItem(SETTINGS_STORAGE, JSON.stringify(next));
  } catch {
    // ignore
  }
  emit();
  return next;
}

// ---------------------------------------------------------------------------
// Hooks
// ---------------------------------------------------------------------------

function keySnapshot(): boolean {
  return getTmdbKey().length > 0;
}

/** Reactive "does the user have a TMDB key" flag. */
export function useHasTmdbKey(): boolean {
  return useSyncExternalStore(subscribe, keySnapshot, () => false);
}

export function useSettings(): CinedeckSettings {
  return useSyncExternalStore(subscribe, getSettings, () => DEFAULT_SETTINGS);
}
